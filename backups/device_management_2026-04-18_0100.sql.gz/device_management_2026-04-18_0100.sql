-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: mysql    Database: device_management
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `device_management`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `device_management` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `device_management`;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_short_name` (`short_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (5,'LKJH','LJKSN','2026-03-02 06:41:36','2026-03-02 06:41:36'),(6,'深圳','SZ','2026-03-02 09:05:41','2026-03-02 09:05:41');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_bundles`
--

DROP TABLE IF EXISTS `device_bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_bundles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bundle_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_bundle_code` (`bundle_code`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `device_bundles_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_bundles`
--

LOCK TABLES `device_bundles` WRITE;
/*!40000 ALTER TABLE `device_bundles` DISABLE KEYS */;
INSERT INTO `device_bundles` VALUES (1,'T-D48425B1',NULL,6,NULL,'2026-03-26 14:55:50','2026-03-26 14:55:50'),(4,'111111','测试多合一',6,'123','2026-03-26 15:47:40','2026-04-16 08:53:42');
/*!40000 ALTER TABLE `device_bundles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_documents`
--

DROP TABLE IF EXISTS `device_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int DEFAULT NULL,
  `uploaded_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `bundle_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_device_category` (`device_id`,`category`),
  KEY `fk_doc_bundle` (`bundle_id`),
  CONSTRAINT `device_documents_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_doc_bundle` FOREIGN KEY (`bundle_id`) REFERENCES `device_bundles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_documents`
--

LOCK TABLES `device_documents` WRITE;
/*!40000 ALTER TABLE `device_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_upgrades`
--

DROP TABLE IF EXISTS `device_upgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_upgrades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upgrade_type` enum('硬件升级','软件更新','系统重装') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `old_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operator_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upgrade_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  CONSTRAINT `device_upgrades_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_upgrades`
--

LOCK TABLES `device_upgrades` WRITE;
/*!40000 ALTER TABLE `device_upgrades` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_upgrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_line_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `product_version_id` int DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('正常','异常','维护中') COLLATE utf8mb4_unicode_ci DEFAULT '正常',
  `remote_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bundle_id` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `product_line_id` (`product_line_id`),
  KEY `customer_id` (`customer_id`),
  KEY `idx_device_code` (`device_code`),
  KEY `idx_product_id` (`product_id`),
  KEY `fk_device_product_version` (`product_version_id`),
  KEY `fk_device_bundle` (`bundle_id`),
  CONSTRAINT `devices_ibfk_1` FOREIGN KEY (`product_line_id`) REFERENCES `product_lines` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `devices_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_device_bundle` FOREIGN KEY (`bundle_id`) REFERENCES `device_bundles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_device_product_version` FOREIGN KEY (`product_version_id`) REFERENCES `product_versions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_devices_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES ('123','123',NULL,'123',8,27,1,6,NULL,'正常',NULL,NULL,'2026-03-05 05:22:03','2026-03-26 14:55:50',1,NULL),('123123123123','123123123123',NULL,'123123123123',7,23,3,6,NULL,'正常','123123123123',NULL,'2026-04-16 07:32:47','2026-04-16 07:45:12',NULL,NULL),('123213123','12321321',NULL,'213213213',7,23,3,6,NULL,'正常','21312312',NULL,'2026-03-26 14:55:36','2026-03-26 14:55:50',1,NULL),('132132123','123132132',NULL,'1321231231',7,23,3,5,NULL,'正常','121212',NULL,'2026-03-26 09:51:51','2026-03-26 09:51:51',NULL,NULL),('222222','111111',NULL,'222222',7,23,3,6,NULL,'正常','111111','111111','2026-03-26 15:47:40','2026-03-26 15:47:40',4,NULL),('333333','111111',NULL,'333333',8,27,1,6,NULL,'正常','111111','111111','2026-03-26 15:47:40','2026-03-26 15:47:40',4,NULL),('456456456','456456456',NULL,'456456456',7,23,3,5,NULL,'正常','456456456',NULL,'2026-04-16 07:46:35','2026-04-16 08:53:14',NULL,'123');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_logs`
--

DROP TABLE IF EXISTS `issue_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `issue_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¤„ç†å†…å®¹æè¿°',
  `operator` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handled_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'å¤„ç†æ—¶é—´',
  `attachments` json DEFAULT NULL COMMENT 'é™„ä»¶',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_issue_id` (`issue_id`),
  KEY `idx_handled_at` (`handled_at`),
  CONSTRAINT `issue_logs_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å”®åŽé—®é¢˜å¤„ç†è®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_logs`
--

LOCK TABLES `issue_logs` WRITE;
/*!40000 ALTER TABLE `issue_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module_id` int DEFAULT NULL,
  `custom_module_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` enum('硬件故障','软件Bug','操作咨询','安装调试','其他') COLLATE utf8mb4_unicode_ci DEFAULT '其他',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_visit_required` tinyint(1) DEFAULT '0',
  `visit_at` timestamp NULL DEFAULT NULL,
  `attachments` json DEFAULT NULL,
  `severity` enum('low','medium','high') COLLATE utf8mb4_unicode_ci DEFAULT 'medium',
  `status` enum('open','in_progress','closed') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `assignee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolution_description` text COLLATE utf8mb4_unicode_ci,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  KEY `module_id` (`module_id`),
  CONSTRAINT `issues_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `issues_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES ('ISS20260326161409','222222',NULL,NULL,'其他','啊',NULL,NULL,0,NULL,NULL,'medium','open','',NULL,NULL,'2026-03-26 16:14:09','2026-03-26 16:14:09');
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kb_articles`
--

DROP TABLE IF EXISTS `kb_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kb_articles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symptom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cause` text COLLATE utf8mb4_unicode_ci,
  `solution` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `product_line_id` int DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `is_pinned` tinyint(1) DEFAULT '0',
  `view_count` int DEFAULT '0',
  `helpful_count` int DEFAULT '0',
  `created_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_line_id` (`product_line_id`),
  CONSTRAINT `kb_articles_ibfk_1` FOREIGN KEY (`product_line_id`) REFERENCES `product_lines` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kb_articles`
--

LOCK TABLES `kb_articles` WRITE;
/*!40000 ALTER TABLE `kb_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `kb_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_sop_templates`
--

DROP TABLE IF EXISTS `module_sop_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_sop_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `module_type_id` int NOT NULL,
  `items` json NOT NULL COMMENT '[{id,text,required}]',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_type_id` (`module_type_id`),
  CONSTRAINT `module_sop_templates_ibfk_1` FOREIGN KEY (`module_type_id`) REFERENCES `module_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_sop_templates`
--

LOCK TABLES `module_sop_templates` WRITE;
/*!40000 ALTER TABLE `module_sop_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `module_sop_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_types`
--

DROP TABLE IF EXISTS `module_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=910106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_types`
--

LOCK TABLES `module_types` WRITE;
/*!40000 ALTER TABLE `module_types` DISABLE KEYS */;
INSERT INTO `module_types` VALUES (437838,'机械','mechanical','设备的机械结构相关',1,'2026-02-26 05:23:33','2026-02-26 05:23:33'),(490266,'上位机软件','software','设备的上位机软件相关',1,'2026-02-26 05:28:13','2026-02-26 05:28:13'),(626828,'车牌相机','License plate camera','车牌识别相机',1,'2026-02-26 05:37:59','2026-02-26 05:37:59'),(713028,'服务器','algorithm','设备的人工智能识别服务器相关',1,'2026-02-26 05:26:41','2026-03-25 03:54:23'),(752682,'电气','electric','设备的电气相关',1,'2026-02-26 05:26:00','2026-02-26 05:26:00'),(910105,'视觉','visual','设备的视觉控制及程序相关',1,'2026-02-26 05:27:24','2026-02-26 05:27:24');
/*!40000 ALTER TABLE `module_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_versions`
--

DROP TABLE IF EXISTS `module_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_versions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `module_id` int NOT NULL,
  `version_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_type` enum('factory','update') COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_date` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `checklist` json DEFAULT NULL COMMENT '更新时SOP检查清单快照',
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`),
  CONSTRAINT `module_versions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=939577 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_versions`
--

LOCK TABLES `module_versions` WRITE;
/*!40000 ALTER TABLE `module_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `module_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_device_module` (`device_id`,`type_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `modules_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `module_types` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=884085 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (884075,'123',490266,'2026-03-05 05:22:03','2026-03-05 05:22:03'),(884076,'123',437838,'2026-03-05 05:22:03','2026-03-05 05:22:03'),(884077,'123',752682,'2026-03-05 05:22:03','2026-03-05 05:22:03'),(884078,'123',713028,'2026-03-05 05:22:03','2026-03-05 05:22:03'),(884079,'123',910105,'2026-03-05 05:22:03','2026-03-05 05:22:03'),(884080,'333333',490266,'2026-03-26 15:47:40','2026-03-26 15:47:40'),(884081,'333333',713028,'2026-03-26 15:47:40','2026-03-26 15:47:40'),(884082,'333333',437838,'2026-03-26 15:47:40','2026-03-26 15:47:40'),(884083,'333333',752682,'2026-03-26 15:47:40','2026-03-26 15:47:40'),(884084,'333333',910105,'2026-03-26 15:47:40','2026-03-26 15:47:40');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_documents`
--

DROP TABLE IF EXISTS `product_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `doc_type` enum('规格书','使用说明','用户手册','其他') COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int DEFAULT NULL,
  `uploaded_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_documents_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_documents`
--

LOCK TABLES `product_documents` WRITE;
/*!40000 ALTER TABLE `product_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_lines`
--

DROP TABLE IF EXISTS `product_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_lines`
--

LOCK TABLES `product_lines` WRITE;
/*!40000 ALTER TABLE `product_lines` DISABLE KEYS */;
INSERT INTO `product_lines` VALUES (4,'天眼云数字化车辆检测设备','Vehicle_Digitalization_Scanner',NULL,1,'2026-02-28 01:52:04','2026-02-28 01:52:04'),(5,'汽车胎纹检测设备','Vehicle_Tire_Tread_Depth_Scanner',NULL,1,'2026-02-28 01:54:04','2026-02-28 01:54:04'),(6,'汽车底盘检测设备','Vehicle_Undercarriage_Inspection_Equipment',NULL,1,'2026-02-28 01:57:11','2026-02-28 01:57:11'),(7,'龙门版全车360°表面缺陷AI检测设备','Arch_Scanner_Dragate',NULL,1,'2026-02-28 02:11:13','2026-02-28 02:11:13'),(8,'轮胎侧面检测设备','Tire_Side_Scanner',NULL,1,'2026-02-28 02:14:39','2026-02-28 02:14:39');
/*!40000 ALTER TABLE `product_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_module_history`
--

DROP TABLE IF EXISTS `product_module_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_module_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `module_type_id` int NOT NULL,
  `is_required` tinyint(1) DEFAULT '1',
  `default_config` json DEFAULT NULL,
  `version_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_description` text COLLATE utf8mb4_unicode_ci,
  `effective_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deprecated_date` timestamp NULL DEFAULT NULL,
  `is_current` tinyint(1) DEFAULT '0',
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_version` (`product_id`,`module_type_id`,`version_number`),
  KEY `module_type_id` (`module_type_id`),
  KEY `idx_product_module_current` (`product_id`,`module_type_id`,`is_current`),
  KEY `idx_current` (`is_current`,`effective_date`),
  CONSTRAINT `product_module_history_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_module_history_ibfk_2` FOREIGN KEY (`module_type_id`) REFERENCES `module_types` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_module_history`
--

LOCK TABLES `product_module_history` WRITE;
/*!40000 ALTER TABLE `product_module_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_module_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_modules`
--

DROP TABLE IF EXISTS `product_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_modules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `module_type_id` int NOT NULL,
  `is_required` tinyint(1) DEFAULT '1',
  `default_config` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `module_type_id` (`module_type_id`),
  CONSTRAINT `product_modules_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_modules_ibfk_2` FOREIGN KEY (`module_type_id`) REFERENCES `module_types` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_modules`
--

LOCK TABLES `product_modules` WRITE;
/*!40000 ALTER TABLE `product_modules` DISABLE KEYS */;
INSERT INTO `product_modules` VALUES (9,27,490266,1,NULL,'2026-03-05 02:59:49'),(10,27,437838,1,NULL,'2026-03-05 02:59:49'),(11,27,752682,1,NULL,'2026-03-05 02:59:49'),(12,27,713028,1,NULL,'2026-03-05 02:59:49'),(13,27,910105,1,NULL,'2026-03-05 02:59:49'),(15,27,626828,0,NULL,'2026-03-05 03:06:23');
/*!40000 ALTER TABLE `product_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_submodule_specs`
--

DROP TABLE IF EXISTS `product_submodule_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_submodule_specs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_module_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specifications` text COLLATE utf8mb4_unicode_ci,
  `default_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_module_id` (`product_module_id`),
  CONSTRAINT `product_submodule_specs_ibfk_1` FOREIGN KEY (`product_module_id`) REFERENCES `product_modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_submodule_specs`
--

LOCK TABLES `product_submodule_specs` WRITE;
/*!40000 ALTER TABLE `product_submodule_specs` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_submodule_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_version_documents`
--

DROP TABLE IF EXISTS `product_version_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_version_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_version_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int DEFAULT NULL,
  `category` enum('规格书','变更记录','图纸','其他') COLLATE utf8mb4_unicode_ci DEFAULT '其他',
  `uploaded_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_version_id` (`product_version_id`),
  CONSTRAINT `product_version_documents_ibfk_1` FOREIGN KEY (`product_version_id`) REFERENCES `product_versions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_version_documents`
--

LOCK TABLES `product_version_documents` WRITE;
/*!40000 ALTER TABLE `product_version_documents` DISABLE KEYS */;
INSERT INTO `product_version_documents` VALUES (1,1,'images (19).jpg','oss://els-pub-04/static/After-sales management system/轮胎侧面检测设备/TSS-PV-2403/V1-2026改款/1772678272017-233611225.jpg','jpg',5397,'其他',NULL,'2026-03-05 02:37:52'),(2,1,'images (18).jpg','oss://els-pub-04/static/After-sales management system/轮胎侧面检测设备/TSS-PV-2403/V1-2026改款/1772678272018-758335345.jpg','jpg',9202,'其他',NULL,'2026-03-05 02:37:52'),(3,1,'images (13).jpg','oss://els-pub-04/static/After-sales management system/Product Line Information/轮胎侧面检测设备/TSS-PV-2403/V1-2026改款/1772678559327-929169893.jpg','jpg',5331,'其他',NULL,'2026-03-05 02:42:39'),(4,1,'images (12).jpg','oss://els-pub-04/static/After-sales management system/Product Line Information/轮胎侧面检测设备/TSS-PV-2403/V1-2026改款/1772678559328-759434972.jpg','jpg',6392,'其他',NULL,'2026-03-05 02:42:39'),(5,3,'images (20).jpg','oss://els-pub-04/static/After-sales management system/Product Line Information/龙门版全车360°表面缺陷AI检测设备/DIA-PV-D/V3.0-DO3.0/images (20).jpg','jpg',8201,'其他',NULL,'2026-03-05 02:56:25'),(6,3,'images (18).jpg','oss://els-pub-04/static/After-sales management system/Product Line Information/龙门版全车360°表面缺陷AI检测设备/DIA-PV-D/V3.0-DO3.0/images (18).jpg','jpg',9202,'其他',NULL,'2026-03-05 02:56:25');
/*!40000 ALTER TABLE `product_version_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_versions`
--

DROP TABLE IF EXISTS `product_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_versions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `version_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `specifications` json DEFAULT NULL,
  `status` enum('开发中','量产中','已停产') COLLATE utf8mb4_unicode_ci DEFAULT '开发中',
  `release_date` date DEFAULT NULL,
  `is_current` tinyint(1) DEFAULT '0',
  `sort_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_product_version` (`product_id`,`version_number`),
  CONSTRAINT `product_versions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_versions`
--

LOCK TABLES `product_versions` WRITE;
/*!40000 ALTER TABLE `product_versions` DISABLE KEYS */;
INSERT INTO `product_versions` VALUES (1,27,'V1','2026改款','','null','量产中','2026-02-28',1,2,'2026-03-05 02:17:35','2026-03-05 02:42:39'),(2,27,'V2','202603最新','','null','量产中','2026-03-03',0,5,'2026-03-05 02:18:19','2026-03-05 02:26:06'),(3,23,'V3.0','DO3.0','无',NULL,'量产中','2026-03-05',1,2,'2026-03-05 02:56:25','2026-03-05 02:57:23');
/*!40000 ALTER TABLE `product_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_line_id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `specifications` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_line_id` (`product_line_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`product_line_id`) REFERENCES `product_lines` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (6,4,'天眼云数字化车辆检测设备-高配版',NULL,'DIS-PV-2006','天眼云 Pro',NULL,1,'2026-02-28 01:52:34','2026-02-28 01:52:34'),(7,4,'天眼云数字化车辆检测设备-优化版',NULL,'VSS-PV-2205','天眼云',NULL,1,'2026-02-28 01:53:03','2026-02-28 01:53:03'),(8,4,'天眼云数字化车辆检测设备-基础版',NULL,'DIS-PV-2302','天眼云 SE',NULL,1,'2026-02-28 01:53:23','2026-02-28 01:53:23'),(9,5,'汽车胎纹检测设备-乘用车版-斜坡款',NULL,'TSD-PV-LG-2010','鲁班尺 Pro',NULL,1,'2026-02-28 01:54:37','2026-02-28 01:54:37'),(10,5,'汽车胎纹检测设备-乘用车版-埋地款',NULL,'TSD-PV-UG-2010','鲁班尺 Pro',NULL,1,'2026-02-28 01:54:59','2026-02-28 01:54:59'),(11,5,'汽车胎纹检测设备-商用车版-斜坡款',NULL,'TSD-CV-LG-2010','鲁班尺 Max',NULL,1,'2026-02-28 01:55:25','2026-02-28 01:56:14'),(12,5,'汽车胎纹检测设备-商用车版-埋地款',NULL,'TSD-CV-UG-2010','鲁班尺 Max',NULL,1,'2026-02-28 01:55:55','2026-02-28 01:55:55'),(13,5,'手持式轮胎花纹深度扫描仪',NULL,'TSD-PV-HH-2110','鲁班尺 Mini',NULL,1,'2026-02-28 01:56:31','2026-02-28 01:56:31'),(14,6,'汽车底盘检测设备-高配版',NULL,'CSD-PV-2012','托塔 Pro',NULL,1,'2026-02-28 01:57:59','2026-02-28 01:57:59'),(15,6,'汽车底盘检测设备（埋地款）-高配版',NULL,'CSD-PV-UG-2201','托塔 Pro',NULL,1,'2026-02-28 01:58:18','2026-02-28 01:58:18'),(16,6,'汽车底盘检测设备-标准版/便携版',NULL,'CSD-PV-OE-2012','托塔',NULL,1,'2026-02-28 01:58:36','2026-02-28 01:58:36'),(17,6,'汽车底盘检测设备（埋地款）-轨交专用-高配版',NULL,'CSD-CV-UG-2112','托塔 Max',NULL,0,'2026-02-28 01:58:54','2026-02-28 02:23:31'),(18,6,'汽车底盘检测设备-轨交专用-高配版',NULL,'CSD-CV-2106','托塔 Max',NULL,1,'2026-02-28 01:59:12','2026-02-28 01:59:12'),(19,6,'斜扫-奔驰专用-定制版',NULL,'CSD-PV-TS-2110',NULL,NULL,1,'2026-02-28 01:59:26','2026-02-28 01:59:26'),(20,7,'龙门版全车360°表面缺陷AI检测设备-专业版',NULL,'DIA-PV-2110','龙门 Pro',NULL,1,'2026-02-28 02:11:33','2026-02-28 02:12:00'),(21,7,'龙门版全车360°表面缺陷AI检测设备-DEMO版',NULL,'DIA-PV-B','龙门 DEMO',NULL,1,'2026-02-28 02:11:52','2026-02-28 02:11:52'),(22,7,'龙门版全车360°表面缺陷AI检测设备-标准版',NULL,'DIA-PV-C','标准龙门，轿车',NULL,1,'2026-02-28 02:12:27','2026-02-28 02:12:27'),(23,7,'龙门版全车360°表面缺陷AI检测设备-DO',NULL,'DIA-PV-D','冰雹龙门，DO',NULL,1,'2026-02-28 02:12:49','2026-02-28 02:12:55'),(24,7,'龙门版全车360°表面缺陷AI检测设备-大车',NULL,'DIA-PV-G','大车',NULL,1,'2026-02-28 02:13:20','2026-02-28 02:13:20'),(25,7,'龙门版全车360°表面缺陷AI检测设备-SE',NULL,'DIA-PV-E','轿车，4S龙门',NULL,1,'2026-02-28 02:13:43','2026-02-28 02:13:43'),(26,7,'龙门版全车360°表面缺陷AI检测设备-板式',NULL,'DIA-PV-F','板式',NULL,1,'2026-02-28 02:14:19','2026-02-28 02:14:19'),(27,8,'轮胎侧面检测设备-乘用车版本-标准版',NULL,'TSS-PV-2403',NULL,NULL,1,'2026-02-28 02:14:57','2026-02-28 02:14:57');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_attachments`
--

DROP TABLE IF EXISTS `release_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `release_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `release_id` int NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `release_id` (`release_id`),
  CONSTRAINT `release_attachments_ibfk_1` FOREIGN KEY (`release_id`) REFERENCES `version_releases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_attachments`
--

LOCK TABLES `release_attachments` WRITE;
/*!40000 ALTER TABLE `release_attachments` DISABLE KEYS */;
INSERT INTO `release_attachments` VALUES (1,12,'1772430981070_chassisconfig.json','chassisconfig.json','oss://els-pub-04/static/After-sales management system/version-releases/视觉/v1.0.10/chassisconfig.json',1763,'2026-03-02 05:56:23'),(2,12,'1772430981076_elscs','elscs','oss://els-pub-04/static/After-sales management system/version-releases/视觉/v1.0.10/elscs',600272,'2026-03-02 05:56:24'),(3,14,'1772432434015_elsss1.0.5','elsss1.0.5','/uploads/release-attachments/1772432434015_elsss1.0.5',1157160,'2026-03-02 06:20:39'),(4,15,'1772435908180_generatekey','generatekey','/uploads/release-attachments/1772435908180_generatekey',243560,'2026-03-02 07:18:33');
/*!40000 ALTER TABLE `release_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sop_templates`
--

DROP TABLE IF EXISTS `sop_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sop_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('日常维护','故障排查','定期检查','升级流程','其他') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '日常维护',
  `product_line_id` int DEFAULT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'v1.0',
  `content` json NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_line_id` (`product_line_id`),
  CONSTRAINT `sop_templates_ibfk_1` FOREIGN KEY (`product_line_id`) REFERENCES `product_lines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sop_templates`
--

LOCK TABLES `sop_templates` WRITE;
/*!40000 ALTER TABLE `sop_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `sop_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submodule_versions`
--

DROP TABLE IF EXISTS `submodule_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submodule_versions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `submodule_id` int NOT NULL,
  `version_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_type` enum('factory','update') COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_date` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `updated_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `submodule_id` (`submodule_id`),
  CONSTRAINT `submodule_versions_ibfk_1` FOREIGN KEY (`submodule_id`) REFERENCES `submodules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submodule_versions`
--

LOCK TABLES `submodule_versions` WRITE;
/*!40000 ALTER TABLE `submodule_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `submodule_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submodules`
--

DROP TABLE IF EXISTS `submodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submodules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `module_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `factory_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('正常','异常','维护中') COLLATE utf8mb4_unicode_ci DEFAULT '正常',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`),
  CONSTRAINT `submodules_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submodules`
--

LOCK TABLES `submodules` WRITE;
/*!40000 ALTER TABLE `submodules` DISABLE KEYS */;
/*!40000 ALTER TABLE `submodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version_release_products`
--

DROP TABLE IF EXISTS `version_release_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `version_release_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `release_id` int NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_release_product` (`release_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `version_release_products_ibfk_1` FOREIGN KEY (`release_id`) REFERENCES `version_releases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `version_release_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version_release_products`
--

LOCK TABLES `version_release_products` WRITE;
/*!40000 ALTER TABLE `version_release_products` DISABLE KEYS */;
INSERT INTO `version_release_products` VALUES (4,12,14),(3,12,15),(2,12,17),(1,12,18),(5,16,27),(6,17,27),(7,18,23);
/*!40000 ALTER TABLE `version_release_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version_releases`
--

DROP TABLE IF EXISTS `version_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `version_releases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `module_type_id` int NOT NULL,
  `version_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_log` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_date` date DEFAULT (curdate()),
  `source` enum('manual','synced') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `module_type_id` (`module_type_id`),
  CONSTRAINT `version_releases_ibfk_1` FOREIGN KEY (`module_type_id`) REFERENCES `module_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version_releases`
--

LOCK TABLES `version_releases` WRITE;
/*!40000 ALTER TABLE `version_releases` DISABLE KEYS */;
INSERT INTO `version_releases` VALUES (12,910105,'v1.0.10','高配版底盘视觉控制部署程序-适用于埋地与非埋地','【新增功能】\n相对于以往版本加入图像锐化功能，使得输出图像更为清晰','汽车底盘检测设备','2026-03-01','manual','2026-03-02 05:56:20','2026-04-17 06:28:48'),(14,910105,'v1.0.5','高配版侧扫视觉控制部署程序','【新增功能】\n将上传重试次数提出配置文件','轮胎侧面检测设备','2026-03-02','manual','2026-03-02 06:20:33','2026-03-02 06:20:33'),(15,910105,'v1.0.0','视觉控制程序加密','为了对设备的程序进行运行时加密','基础程序','2026-03-02','manual','2026-03-02 07:18:28','2026-03-02 07:18:28'),(16,437838,'V1','2026改款','',NULL,'2026-02-28','synced','2026-04-17 08:31:05','2026-04-17 10:48:11'),(17,437838,'V2','202603最新','',NULL,'2026-03-03','synced','2026-04-17 08:31:05','2026-04-17 10:48:11'),(18,437838,'V3.0','DO3.0','无',NULL,'2026-03-05','synced','2026-04-17 08:31:05','2026-04-17 10:48:11');
/*!40000 ALTER TABLE `version_releases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'device_management'
--

--
-- Dumping routines for database 'device_management'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-18  1:00:02
